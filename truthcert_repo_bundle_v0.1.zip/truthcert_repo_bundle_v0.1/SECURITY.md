# Security Policy

If you discover a vulnerability in runnable code here, please report responsibly (prefer private first).
Include a minimal reproduction + impact.
