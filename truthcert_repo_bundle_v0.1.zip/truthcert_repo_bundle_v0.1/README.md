# TruthCert (docs + runnable benchmark scaffolding)

This bundle includes:
- **Frozen public spec** (`/spec`)
- **Domain pack definitions** (`/packs`)
- **Certification badge + disclosure template** (`/templates`)
- **Runnable simulation benchmarks** (`/benchmarks/simulated`)
- **Real-RCT benchmark skeleton (v0.1)** (`/benchmarks/real-rct-v0.1`)
- **Examples** showing SHIPPED vs REJECTED artifacts (`/examples`)

## Quick start (simulation harness)
```bash
cd benchmarks/simulated
python truthcert_toy_benchmark.py
python truthcert_12pack_benchmark_v1.py --n 4800 --seed 2026
python truthcert_12pack_balanced_policy_v1.py
```

## “Real-RCT Benchmark v0.1” (skeleton)
Fill in:
- `benchmarks/real-rct-v0.1/papers.csv` (OA links + SHA256)
- `benchmarks/real-rct-v0.1/gold.csv` (gold extraction)
- `benchmarks/real-rct-v0.1/tasks.jsonl` (one strict task per paper)

Collect model runs into:
- `benchmarks/real-rct-v0.1/runs/<protocol>/*.jsonl`

Score with:
```bash
python tools/score_contract_v1.py benchmarks/real-rct-v0.1
```
