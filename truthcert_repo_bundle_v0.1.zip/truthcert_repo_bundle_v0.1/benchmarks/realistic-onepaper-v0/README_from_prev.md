# TruthCert realistic mini-suite v0 (1 paper, 5 tasks)

This is a *starter* realistic suite built from an actual published RCT paper:

- DOI: 10.1186/s12884-022-04530-4 (BMC Pregnancy and Childbirth, 2022)
- Task set: numeric extraction + trial overview

## Files
- `real_scenarios.jsonl` — 5 tasks with gold answers.
- `simulate_truthcert_vs_rct_pack.py` — Monte Carlo simulation showing when adding **TC-RCT** helps / hurts, under explicit assumptions.

## Why this is only a starter
A real benchmark should include dozens–hundreds of papers, with:
- PDFs cached locally (or fetched with deterministic URLs),
- page/table-cell provenance,
- a "gold" extraction produced by double data extraction.

## Provenance note
For now, provenance pointers refer to the tool-view lines captured during creation (turn22view0).
When you expand the suite, replace these with: `(pdf page, table id, row/col, cell text)`.
