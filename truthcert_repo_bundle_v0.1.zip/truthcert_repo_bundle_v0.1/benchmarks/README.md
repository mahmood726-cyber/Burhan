# Benchmarks

- `/simulated/` : toy + “richer toy” harnesses
- `/real-rct-v0.1/` : skeleton for real-paper RCT extraction benchmarking

## Contract v1 required reporting (minimum)
- shipped_pct
- false_ship_pct
- reject_pct
- mean_tokens_per_bundle
- tokens_per_correct_shipped
