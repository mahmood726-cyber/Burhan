---
name: "False-ship report"
about: "Report a shipped-but-wrong TruthCert bundle"
title: "[FALSE-SHIP] "
labels: ["bug", "false-ship"]
---

## What shipped
- bundle_hash:
- run_id:
- policy_anchor ref:

## What was wrong (critical fields)
- field:
- expected:
- got:
- why critical:

## Minimal reproduction
- source doc hash / link:
- output JSONL line (paste):
- steps:
