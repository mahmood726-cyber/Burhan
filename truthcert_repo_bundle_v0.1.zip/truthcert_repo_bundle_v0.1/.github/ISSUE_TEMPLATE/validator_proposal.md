---
name: "Validator proposal"
about: "Propose a new validator (include fp/coverage/no-regression evidence)"
title: "[VALIDATOR] "
labels: ["enhancement", "validator"]
---

## Validator ID / name
## Failure modes caught
## Pack(s)
## Inputs / outputs (schema)
## Expected cost

## Evidence
- false_positive_rate:
- coverage:
- no_regression_on_existing: yes/no
- test suite / link:

## Version bump notes
