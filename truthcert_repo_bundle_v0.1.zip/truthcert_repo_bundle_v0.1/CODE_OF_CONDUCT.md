# Code of Conduct

Be kind, be rigorous, and assume good intent.

Unacceptable: harassment, discrimination, doxxing, threats.
